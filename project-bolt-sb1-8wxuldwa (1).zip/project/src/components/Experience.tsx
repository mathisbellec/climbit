import React from 'react';
import { Trophy, Target, Activity, Award } from 'lucide-react';

export function Experience() {
  const features = [
    {
      icon: <Trophy className="w-8 h-8 text-emerald-600" />,
      title: "Défis personnalisés",
      description: "Des challenges adaptés à votre niveau pour progresser à votre rythme"
    },
    {
      icon: <Target className="w-8 h-8 text-emerald-600" />,
      title: "Suivi des performances",
      description: "Visualisez votre progression et analysez vos sessions"
    },
    {
      icon: <Activity className="w-8 h-8 text-emerald-600" />,
      title: "Classements en temps réel",
      description: "Comparez-vous aux autres grimpeurs et relevez des défis"
    },
    {
      icon: <Award className="w-8 h-8 text-emerald-600" />,
      title: "Badges et récompenses",
      description: "Débloquez des succès et gagnez des récompenses exclusives"
    }
  ];

  return (
    <section id="experience" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">L'expérience grimpeur</h2>
          <p className="text-xl text-gray-600">Scannez, grimpez, dépassez-vous !</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition"
            >
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}