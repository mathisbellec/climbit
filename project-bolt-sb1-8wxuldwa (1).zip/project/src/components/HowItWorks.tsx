import React from 'react';
import { Smartphone, ArrowRight, BarChart3 } from 'lucide-react';

export function HowItWorks() {
  const steps = [
    {
      icon: <Smartphone className="w-12 h-12 text-emerald-600" />,
      title: "Connectez-vous",
      description: "Activez votre bracelet ou votre application"
    },
    {
      icon: <ArrowRight className="w-12 h-12 text-emerald-600" />,
      title: "Grimpez",
      description: "Scannez au départ et à l'arrivée des voies"
    },
    {
      icon: <BarChart3 className="w-12 h-12 text-emerald-600" />,
      title: "Progressez",
      description: "Gagnez des points et débloquez des défis"
    }
  ];

  return (
    <section id="how-it-works" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Comment ça marche</h2>
          <p className="text-xl text-gray-600">Une expérience simple et intuitive</p>
        </div>

        <div className="flex flex-col md:flex-row justify-center items-center gap-8">
          {steps.map((step, index) => (
            <div key={index} className="text-center max-w-xs">
              <div className="mb-6 flex justify-center">{step.icon}</div>
              <h3 className="text-2xl font-semibold mb-2">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}