import React from 'react';
import { Menu, X } from 'lucide-react';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  const scrollToContact = () => {
    const contactSection = document.getElementById('contact');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="fixed w-full bg-white/95 backdrop-blur-sm z-50 shadow-sm">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="text-2xl font-bold text-emerald-600">ClimbIt</div>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <a href="#experience" className="text-gray-600 hover:text-emerald-600">L'expérience</a>
            <a href="#why-us" className="text-gray-600 hover:text-emerald-600">Pourquoi nous choisir</a>
            <a href="#how-it-works" className="text-gray-600 hover:text-emerald-600">Comment ça marche</a>
            <a href="#pricing" className="text-gray-600 hover:text-emerald-600">Tarifs</a>
            <a href="#contact" className="text-gray-600 hover:text-emerald-600">Contact</a>
          </nav>

          <button 
            onClick={scrollToContact}
            className="hidden md:block px-6 py-2 bg-emerald-600 text-white rounded-full hover:bg-emerald-700 transition"
          >
            Demander une démo
          </button>

          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      {isMenuOpen && (
        <div className="md:hidden">
          <nav className="flex flex-col space-y-4 px-4 py-6 bg-white">
            <a href="#experience" className="text-gray-600">L'expérience</a>
            <a href="#why-us" className="text-gray-600">Pourquoi nous choisir</a>
            <a href="#how-it-works" className="text-gray-600">Comment ça marche</a>
            <a href="#pricing" className="text-gray-600">Tarifs</a>
            <a href="#contact" className="text-gray-600">Contact</a>
            <button 
              onClick={scrollToContact}
              className="w-full px-6 py-2 bg-emerald-600 text-white rounded-full"
            >
              Demander une démo
            </button>
          </nav>
        </div>
      )}
    </header>
  );
}