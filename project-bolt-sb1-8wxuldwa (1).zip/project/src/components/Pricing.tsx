import React from 'react';
import { Check } from 'lucide-react';

export function Pricing() {
  const features = [
    {
      title: "Hardware inclus",
      items: [
        "1 capteur RFID",
        "3 bracelets connectés pour grimpeurs",
        "Maintenance incluse"
      ]
    },
    {
      title: "Logiciel pour les salles",
      items: [
        "Tableau de bord CRM",
        "Outils de fidélisation",
        "Notifications personnalisées"
      ]
    },
    {
      title: "Logiciel pour les grimpeurs",
      items: [
        "Application mobile intuitive",
        "Classements et récompenses",
        "Suivi de progression"
      ]
    }
  ];

  return (
    <section id="pricing" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Tarif unique : 30€ par capteur</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Une solution complète pour transformer l'expérience de votre salle
          </p>
        </div>

        <div className="max-w-lg mx-auto mb-16">
          <div className="bg-white p-8 rounded-xl shadow-sm text-center">
            <div className="text-5xl font-bold mb-2">30€<span className="text-lg font-normal text-gray-600">/mois</span></div>
            <p className="text-gray-600 mb-8">Frais de mise en place uniques : 200€ par installation</p>
            <a 
              href="#contact"
              className="block w-full px-6 py-4 bg-emerald-600 text-white text-center rounded-full hover:bg-emerald-700 transition text-lg font-semibold"
            >
              Commencer maintenant
            </a>
          </div>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="bg-white p-8 rounded-xl shadow-sm">
                <h3 className="text-xl font-bold mb-6">{feature.title}</h3>
                <ul className="space-y-4">
                  {feature.items.map((item, itemIndex) => (
                    <li key={itemIndex} className="flex items-center">
                      <Check className="w-5 h-5 text-emerald-600 mr-2 flex-shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}