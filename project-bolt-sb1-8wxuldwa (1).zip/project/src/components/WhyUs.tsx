import React from 'react';
import { Users, TrendingUp, LineChart, Clock } from 'lucide-react';

export function WhyUs() {
  const benefits = {
    climbers: [
      {
        icon: <Users className="w-8 h-8 text-emerald-600" />,
        title: "Expérience gamifiée",
        description: "Des défis personnalisés et des récompenses pour motiver chaque session."
      },
      {
        icon: <LineChart className="w-8 h-8 text-emerald-600" />,
        title: "Suivi des performances",
        description: "Une application dédiée qui trace les réussites et permet de se fixer des objectifs."
      },
      {
        icon: <Users className="w-8 h-8 text-emerald-600" />,
        title: "Communauté et fun",
        description: "Une expérience sociale renforcée grâce à des classements et des compétitions amicales."
      }
    ],
    gyms: [
      {
        icon: <TrendingUp className="w-8 h-8 text-emerald-600" />,
        title: "Fidélisation accrue",
        description: "Réduisez le churn en transformant les grimpeurs occasionnels en membres réguliers."
      },
      {
        icon: <TrendingUp className="w-8 h-8 text-emerald-600" />,
        title: "Augmentation du ticket moyen",
        description: "Boostez les ventes grâce à des récompenses liées au restaurant ou à la boutique."
      },
      {
        icon: <LineChart className="w-8 h-8 text-emerald-600" />,
        title: "Insights sur la clientèle",
        description: "Une meilleure compréhension des comportements des grimpeurs pour optimiser la gestion."
      },
      {
        icon: <Clock className="w-8 h-8 text-emerald-600" />,
        title: "Optimisation de l'affluence",
        description: "Notifications personnalisées pour inciter les visites en périodes creuses."
      }
    ]
  };

  return (
    <section id="why-us" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Pourquoi nous choisir ?</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            La première solution qui transforme l'escalade en une expérience ludique, engageante et rentable pour les salles.
          </p>
        </div>

        <div className="mb-20">
          <h3 className="text-2xl font-bold mb-8 text-center">Pour les grimpeurs</h3>
          <div className="grid md:grid-cols-3 gap-8">
            {benefits.climbers.map((benefit, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-xl">
                <div className="mb-4">{benefit.icon}</div>
                <h4 className="text-xl font-semibold mb-2">{benefit.title}</h4>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-2xl font-bold mb-8 text-center">Pour les salles d'escalade</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.gyms.map((benefit, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-xl">
                <div className="mb-4">{benefit.icon}</div>
                <h4 className="text-xl font-semibold mb-2">{benefit.title}</h4>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 text-center">
          <blockquote className="text-xl italic text-gray-600 mb-8">
            "Depuis que nous utilisons cette solution, nous avons augmenté la fréquentation de 20 % et les ventes au restaurant de 15 %."
          </blockquote>
          <a 
            href="#contact"
            className="inline-block px-8 py-3 bg-emerald-600 text-white rounded-full hover:bg-emerald-700 transition"
          >
            Découvrir comment transformer votre salle
          </a>
        </div>
      </div>
    </section>
  );
}