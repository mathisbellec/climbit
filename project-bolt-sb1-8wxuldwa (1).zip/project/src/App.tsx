import React from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Experience } from './components/Experience';
import { WhyUs } from './components/WhyUs';
import { HowItWorks } from './components/HowItWorks';
import { Pricing } from './components/Pricing';
import { Contact } from './components/Contact';

function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <Hero />
      <Experience />
      <WhyUs />
      <HowItWorks />
      <Pricing />
      <Contact />
    </div>
  );
}

export default App;